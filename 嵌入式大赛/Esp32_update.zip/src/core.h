#ifndef CORE_H
#define CORE_H // Json 解析
#include <ArduinoJson.h>
#include <SPI.h>
#include <TFT_eSPI.h> // Arduino LCD library
#include "string.h"
#include "FS.h"
#include "SPIFFS.h"
#include "HardwareSerial.h"
#include <lvgl.h>
#include <TFT_eSPI.h>
#include <stdio.h>
#include <stdlib.h>
#include <WiFi.h>
#include <WiFiUdp.h> //调用WIFIUDP库
#include <Adafruit_Sensor.h>
#include <Adafruit_BME280.h>
#include <Adafruit_SSD1306.h>

#define I2C_SDA_BME 32  // 定义 BME280 SDA引脚
#define I2C_SCL_BME 33  // 定义 BME280 SCL引脚
#define ADC_LUX_PIN 35  // 定义 光强 ADC引脚
#define ADC_BAT_PIN 34  // 定义 BAT ADC引脚
#define ADC_AQI_PIN 39  // 定义 AQI ADC引脚
#define I2C_SDA_OLED 17 // 定义 OLED SDA引脚
#define I2C_SCL_OLED 16 // 定义 OLED SCL引脚

bool connect_flag=false;
int LightLux, AQI_Value, Bat_Value;
float Temperature, Airpressure, Humidity;
String Post_String;

// unsigned int ServiPort = 2001;    // 通讯端口
// unsigned int localPort_RX = 2002; // 通讯端口
// unsigned int localPort_TX = 2003; // 通讯端口
const char *ssid = "B306";        // localIP: 192.168.1.113
const char *password = "306306306";
// const char *ssid = "Easoom_WIFI";
// const char *password = "Easoom1111";



// TCP通信
WiFiClient client; //ESP32设置成客户端，用于连接服务器
// const IPAddress serverIP(192,168,1,189); //访问服务器的IP地址 （PC_B306）
// const IPAddress serverIP(192,168,1,193); //访问服务器的IP地址 （树莓派_B306）
const IPAddress serverIP(192,168,1,127); //访问服务器的IP地址 （long_B306）
uint16_t serverPort = 2002; //连接服务器的端口号
String readTCP; //存储客户端发送来的字符串




// IPAddress ipServidor(192, 168, 4, 1); // 主机IP
// IPAddress ipCliente(192, 168, 4, 2);  // 本机IP
// IPAddress Subnet(255, 255, 255, 0);   // 网络掩码


void *SubTask_01_P;             // freertos任务参数
TaskHandle_t SubTask_01_Handle; //  main GUI 绘制任务句柄
void *SubTask_02_P;             // freertos任务参数
TaskHandle_t SubTask_02_Handle; //  main GUI 绘制任务句柄


#endif