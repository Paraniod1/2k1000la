// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({env: cloud.DYNAMIC_CURRENT_ENV}) // 使用当前云环境
//引入发送邮件的类库
var nodemailer = require('nodemailer')
// 创建一个SMTP客户端配置
var config = {
//   host: 'smtp.qq.com', //网易163邮箱 smtp.163.com
//   port: 465, //网易邮箱端口 25
//   auth: {
//     user: '443989074@qq.com', //邮箱账号
//     pass: 'vapqqbzxdmtubhbb' //邮箱的授权码  ryxhuiifvcnsbhci
//   }
  host: 'smtp.163.com', //网易163邮箱 smtp.163.com
  port: 25, //网易邮箱端口 25
  auth: {
    user: 'c443989074@163.com', //邮箱账号
    pass: 'DSJJTUKGYLRRUQCV' //邮箱的授权码  
  }
};
// 创建一个SMTP客户端对象
var transporter = nodemailer.createTransport(config);
// 云函数入口函数
exports.main = async (event, context) => {
    console.log(event.error)
    var data = event.error
    var text = "设备" + data.device + "异常！"
    if(data.Temperature == 1)
        text = text + " 温度过高！"
    else if(data.Temperature == -1)
        text = text + " 温度过低！"

    if(data.Humidity == 1)
        text = text + " 湿度过高！"
    else if(data.Humidity == -1)
        text = text + " 湿度过低！"

    if(data.LightLux == 1)
        text = text + " 光强过高！"
    else if(data.LightLux == -1)
        text = text + " 光强过低！"    

    if(data.Airpressure == 1)
        text = text + " 气压过高！"
    else if(data.Airpressure == -1)
        text = text + " 气压过低！"

    if(data.AQI == 1)
        text = text + " 空气质量差！"

    if(data.batpt == 1)
        text = text + " 电量过低！"
    // 创建一个邮件对象
    var mail = {
        // 发件人
        from: '来自超爹 <c443989074@163.com>',
        // 主题
        subject: "设备" + data.device + "异常！",
        // 收件人
        to: '754170055@qq.com',
        // 邮件内容，text或者html格式
        text: text //可以是链接，也可以是验证码
    };
    let res = await transporter.sendMail(mail);
    return res;
}