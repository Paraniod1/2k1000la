// pages/home/home.js
var mqtt = require('../../utils/mqtt_min.js') //根据自己存放的路径修改
const crypto = require('../../utils/hex_hmac_sha1.js'); //根据自己存放的路径修改
import * as echarts from '../../components/ec-canvas/echarts';

const db = wx.cloud.database()

var app = getApp()

var x_data = []
for (let index = 1; index <= 1000; index++) {
    x_data.push("-" + index)
}

Page({
    /**
     * 页面的初始数据
     */
    data: {
        tabber_name:0,
        choose_shebei_show:0,
        cur_shebei:0,
        shebei_name:[
            {
                name:"设备1",
                index:0,
            },
            {
                name:"设备2",
                index:1,
            },
            {
                name:"设备3",
                index:2,
            },
            {
                name:"设备4",
                index:3,
            }],
        show_info:[
            {
                title:"温度",
                abridge:"Temperature",
                content:"-",
                unit:"℃"
            },
            {
                title:"湿度",
                abridge:"Humidity",
                content:"-",
                unit:"%"
            },
            {
                title:"光强",
                abridge:"LightLux",
                content:"-",
                unit:"Lux"
            },
            {
                title:"气压",
                abridge:"Airpressure",
                content:"-",
                unit:"Pa"
            },
            {
                title:"AQI",
                abridge:"AQI",
                content:"-",
                unit:" "
            },
            {
                title:"电量",
                abridge:"batpt",
                content:"-",
                unit:"%"
            }],

        ec: {
            lazyLoad: true
        },
        sensor_data:{
            device_1:{
                Temperature:[2],
                Humidity:[2],
                LightLux:[2],
                AQI:[4],
                Airpressure:[5],
                batpt:[6],
                get_value_flag:0
            },
            device_2:{
                Temperature:[],
                Humidity:[],
                LightLux:[],
                AQI:[],
                Airpressure:[],
                batpt:[],
                get_value_flag:0
            },
            device_3:{
                Temperature:[],
                Humidity:[],
                LightLux:[],
                AQI:[],
                Airpressure:[],
                batpt:[],
                get_value_flag:0
            },
            device_4:{
                Temperature:[],
                Humidity:[],
                LightLux:[],
                AQI:[],
                Airpressure:[],
                batpt:[],
                get_value_flag:0
            },
        },
        dropdown_option: [
        { text: '温度', value: 0, abridge:"Temperature"},
        { text: '湿度', value: 1 , abridge:"Humidity"},
        { text: '光强', value: 2 , abridge:"LightLux"},
        { text: '气压', value: 3 , abridge:"Airpressure"},
        { text: 'AQI', value: 4 , abridge:"AQI"},
        { text: '电量', value: 5 , abridge:"batpt"},
        ],
        dropdown_value: 0,
    },

    doConnect(){
        let _this = this
        const deviceConfig = {
          productKey: "hjulRxHxTsF",
          deviceName: "wechat",
          deviceSecret: "3630cbded3d2d03b2af3bc3a631f7aab",
          regionId: "cn-shanghai"//根据自己的区域替换
        };
        const options = this.initMqttOptions(deviceConfig);
        console.log(options)
        //替换productKey为你自己的产品的（注意这里是wxs，不是wss，否则你可能会碰到ws不是构造函数的错误）
        const client = mqtt.connect('wxs://hjulRxHxTsF.iot-as-mqtt.cn-shanghai.aliyuncs.com',options)
        client.on('connect', function () {
            console.log('连接服务器成功')
            //注意：订阅主题，替换productKey和deviceName(这里的主题可能会不一样，具体请查看控制台-产品详情-Topic 类列表下的可订阅主题)，并且确保改主题的权限设置为可订阅
            // client.subscribe('/productKey/deviceName/user/get', function (err) {
            //     if (!err) {
            //     console.log('订阅成功！');
            //     }
            // })
        })
        //接收消息监听
        client.on('message', function (topic, message) {
            // message is Buffer
            let msg = message.toString();
            // console.log('收到消息的主题：');
            // console.log(topic);
            // console.log('收到消息：');
            // console.log(msg);
            for(let i = 1; i <= Object.keys(_this.data.sensor_data).length; i++)
            {
                let device = "device_" + i
                // console.log(device)
                if(msg.indexOf(device + ":") >= 1){
                    // json字符串转json对象
                    let jsonitem = JSON.parse(msg).items
                    // console.log(jsonitem)
                    let error={
                        device:i,
                        Temperature:0,
                        Humidity:0,
                        LightLux:0,
                        Airpressure:0,
                        AQI:0,
                        batpt:0,
                        sendEmail_flag:0
                    }
                    for(let j = 0; j < Object.keys(_this.data.show_info).length; j++){
                        _this.data.sensor_data[device][_this.data.show_info[j].abridge].unshift(jsonitem[device + ":" + _this.data.show_info[j].abridge].value)
                        if(_this.data.show_info[j].abridge == 'Temperature'){
                            if(jsonitem[device + ":" + _this.data.show_info[j].abridge].value > 40){
                                error.Temperature=1
                                error.sendEmail_flag=1
                            }else if(jsonitem[device + ":" + _this.data.show_info[j].abridge].value < 15){
                                error.Temperature=-1
                                error.sendEmail_flag=1
                            }
                        }else if(_this.data.show_info[j].abridge == 'Humidity'){
                            if(jsonitem[device + ":" + _this.data.show_info[j].abridge].value > 70){
                                error.Humidity=1
                                error.sendEmail_flag=1
                            }else if(jsonitem[device + ":" + _this.data.show_info[j].abridge].value < 20){
                                error.Humidity=-1
                                error.sendEmail_flag=1
                            }
                        }
                        else if(_this.data.show_info[j].abridge == 'LightLux'){
                            if(jsonitem[device + ":" + _this.data.show_info[j].abridge].value > 700){
                                error.LightLux=1
                                error.sendEmail_flag=1
                            }else if(jsonitem[device + ":" + _this.data.show_info[j].abridge].value < 150){
                                error.LightLux=-1
                                error.sendEmail_flag=1
                            }
                        }
                        else if(_this.data.show_info[j].abridge == 'Airpressure'){
                            if(jsonitem[device + ":" + _this.data.show_info[j].abridge].value > 980){
                                error.Airpressure=1
                                error.sendEmail_flag=1
                            }else if(jsonitem[device + ":" + _this.data.show_info[j].abridge].value < 930){
                                error.Airpressure=-1
                                error.sendEmail_flag=1
                            }
                        }
                        else if(_this.data.show_info[j].abridge == 'AQI'){
                            if(jsonitem[device + ":" + _this.data.show_info[j].abridge].value > 50){
                                error.AQI=1
                                error.sendEmail_flag=1
                            }
                        }
                        else if(_this.data.show_info[j].abridge == 'batpt'){
                            if(jsonitem[device + ":" + _this.data.show_info[j].abridge].value < 20){
                                error.batpt=1
                                error.sendEmail_flag=1
                            }
                        }
                    }
                    if(error.sendEmail_flag == 1){
                        wx.cloud.callFunction({
                            name:"sendEmail",
                            data:{
                                error
                            },
                            success(res){
                                console.log("发送成功",res)
                            },
                            fail(res){
                                console.log("发送失败",res)
                            }
                        })
                    }
                    if(Object.keys(_this.data.show_info).length > 1000)
                        Object.keys(_this.data.show_info).length = 1000
                    _this.data.sensor_data[device].get_value_flag = 1
                    // console.log(_this.data.sensor_data[device])
                    break;
                }
            }

            _this.setData({
                // show_info: _this.data.show_info,
                sensor_data: _this.data.sensor_data
            })
            //关闭连接 client.end()
        })
    },

    /**
     * IoT平台mqtt连接参数初始化
     * @param {*} deviceConfig 
     */
    initMqttOptions(deviceConfig) {
        const params = {
          productKey: deviceConfig.productKey,
          deviceName: deviceConfig.deviceName,
          timestamp: Date.now(),
          clientId: Math.random().toString(36).substr(2),
        }
        //CONNECT参数
        const options = {
            keepalive: 60, //60s
            clean: true, //cleanSession不保持持久会话
            protocolVersion: 4 //MQTT v3.1.1
        }
        //1.生成clientId，username，password
        options.password = this.signHmacSha1(params, deviceConfig.deviceSecret);
        options.clientId = `${params.clientId}|securemode=2,signmethod=hmacsha1,timestamp=${params.timestamp}|`;
        options.username = `${params.deviceName}&${params.productKey}`;
        return options;
    },

    /*
      生成基于HmacSha1的password
      参考文档：https://help.aliyun.com/document_detail/73742.html?#h2-url-1
    */
    signHmacSha1(params, deviceSecret) {
        let keys = Object.keys(params).sort();
        // 按字典序排序
        keys = keys.sort();
        const list = [];
        keys.map((key) => {
        list.push(`${key}${params[key]}`);
        });
        const contentStr = list.join('');
        return crypto.hex_hmac_sha1(deviceSecret, contentStr);
    },

    onChange_tabber(event) {
        // event.detail 的值为当前选中项的索引
        this.setData({ tabber_name: event.detail });
        if(event.detail == 1){
            //获取到组件
            this.lazyComponent = this.selectComponent('#mychart')
            this.initChart([])
            setTimeout(() => {
                setInterval(()=>{
                    let data1, data2, data3, data4;
                    data1 = this.data.sensor_data["device_1"][this.data.dropdown_option[this.data.dropdown_value].abridge]
                    data2 = this.data.sensor_data["device_2"][this.data.dropdown_option[this.data.dropdown_value].abridge]
                    data3 = this.data.sensor_data["device_3"][this.data.dropdown_option[this.data.dropdown_value].abridge]
                    data4 = this.data.sensor_data["device_4"][this.data.dropdown_option[this.data.dropdown_value].abridge]
                    let option = getOption(data1, data2, data3, data4)
                    this.chart.setOption(option)
                },1000); // 创建定时器，每个 1s 触发一次 timechange()函数
            }, 500)
        }
        // console.log(this.data.tabber_name)
    },

    choose_shebei_func(){
        this.setData({ choose_shebei_show: true })
    },

    onClose() {
        this.setData({ choose_shebei_show: false });
    },
    
    onSelect(event) {
        console.log(event.detail);
        this.setData({ cur_shebei: event.detail.index})
        for (let index = 0; index < this.data.show_info.length; index++) {
            this.data.show_info[index].content = '-'
        }
        this.setData({ show_info: this.data.show_info })
    },

    initChart(optionData) {
        this.lazyComponent.init((canvas, width, height, dpr) => {
            let chart = echarts.init(canvas, null, {
                    width: width,
                    height: height,
                    devicePixelRation: dpr
            })
            let option = getOption(optionData)  // echarts的配置信息
            this.chart = chart //将图表实例绑定到this上，方便其他函数访问
            chart.setOption(option);
            return chart;
        })
    },

    onchange_drop(value){
        console.log(value.detail)
        this.setData({dropdown_value: value.detail})
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        this.doConnect();
        setInterval(()=>{
            for(let i = 0; i < Object.keys(this.data.show_info).length; i++){
                let title = this.data.show_info[i].abridge
                let index = this.data.cur_shebei + 1
                this.data.show_info[i].content = this.data.sensor_data["device_" + index][title][0]
            }
            this.setData({
                show_info: this.data.show_info,
            })
        },1000); // 创建定时器，每个 1s 触发一次 timechange()函数
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {
        let _this = this
        setInterval(()=>{
            for(let i = 1; i <= Object.keys(_this.data.sensor_data).length; i++)
            {
                let device = "device_" + i
                if(_this.data.sensor_data[device].get_value_flag == 0){
                    for(let j = 0; j < Object.keys(_this.data.show_info).length; j++){
                        _this.data.sensor_data[device][_this.data.show_info[j].abridge].unshift("-")
                    }
                }else{
                    _this.data.sensor_data[device].get_value_flag = 0
                }

                if(Object.keys(_this.data.show_info).length > 1000)
                    Object.keys(_this.data.show_info).length = 1000
            }
        },1200)
    },
    // button_tap()
    // {
    //     db.collection('test').doc('c9391ab964b3cafe01124e947e99bb3e').update({
    //         // data 传入需要局部更新的数据
    //         data: {
    //             "device_1": this.data.sensor_data.device_1
    //         },
    //         success: function(res) {
    //           console.log(res.data)
    //         }
    //     })
    // },



    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})

function getOption(data1, data2, data3, data4){
    return {
      legend: {
        data: ['设备一', '设备二', '设备三', '设备四'],
        top: 0,
        left: 'center',
        width: '90%',
        z: 100
      },
      grid: {
        containLabel: true
      },
      tooltip: {
          feature: {
              dataZoom: {
                  yAxisIndex: 'none'
              },
          },
          show: true,
          trigger: 'axis'
      },
      xAxis: [{
              type: 'category',
              name: '时间',
              boundaryGap: true,
              data: x_data
      }],
      yAxis: [{
          x: 'center',
          position: 'left',
          type: 'value',
          splitLine: {
            lineStyle: {
              type: 'dashed'
            }
          }
      }],
      dataZoom: [
          {
            type: 'inside',
          },
          {
            start: 0,
            end: 10
          }
      ],
      series: [{
        name: '设备一',
        type: 'line',
        smooth: true,
        sampling: 'lttb',      
      //   itemStyle: {
      //     color: 'rgb(255, 70, 131)'
      //   },
        data: data1
      },{
        name: '设备二',
        type: 'line',
        smooth: true,
        sampling: 'lttb',
        data: data2
      },{
        name: '设备三',
        type: 'line',
        smooth: true,
        sampling: 'lttb',
        data: data3
      },{
        name: '设备四',
        type: 'line',
        smooth: true,
        sampling: 'lttb',
        data: data4
      },]
    }; 
}