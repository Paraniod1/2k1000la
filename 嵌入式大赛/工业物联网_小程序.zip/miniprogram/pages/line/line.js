import * as echarts from '../../components/ec-canvas/echarts';

const app = getApp();

// for (let i = 1; i < 1000; i++) {
//     var now = new Date((base += oneDay));
//     date.push([now.getFullYear(), now.getMonth() + 1, now.getDate()].join('/'));
//     data.push(Math.round((Math.random() - 0.5) * 20 + data[i - 1]));
// }

Page({
  data: {
    ec: {
      lazyLoad: true
    },
    flag: 0,
    data1:[1,2,3,4,5,6,7],
    data2:[8,7,6,5,4,3,2],
    option1: [
      { text: '温度', value: 0 },
      { text: '湿度', value: 1 },
      { text: '光强', value: 2 },
    ],
    value1: 0,
  },

  button_tap()
  {
        // wx.cloud.callFunction({
        //     name:"sendEmail",
        //     success(res){
        //         console.log("发送成功",res)
        //     },
        //     fail(res){
        //         console.log("发送失败",res)
        //     }
        // })


    console.log(this.data.data1)
    var that = this
    this.data.data1.push(this.data.data1[0] + 1);
    // this.data.data1.length = 7;  
    this.data.data2.push(this.data.data2[0] + 1);
    // this.data.data2.length = 7;
    this.setData({
      data1: this.data.data1,
      data2: this.data.data2
    })
    let option = getOption(this.data.data1, this.data.data2)
    this.chart.setOption(option)
  },

  onLoad(options) {
    //获取到组件
    let that = this;
    this.lazyComponent = this.selectComponent('#mychart')
    this.initChart([])
    setTimeout(() => {
      this.initChart([])
    }, 500)
  },

  initChart(optionData) {
    this.lazyComponent.init((canvas, width, height, dpr) => {
        let chart = echarts.init(canvas, null, {
                width: width,
                height: height,
                devicePixelRation: dpr
        })
        let option = getOption(optionData)  // echarts的配置信息
        this.chart = chart //将图表实例绑定到this上，方便其他函数访问
        chart.setOption(option);
        return chart;
    })
  },

});


function getOption(data1, data2){
  return {
    legend: {
      data: ['设备一', '设备二'],
      top: 0,
      left: 'center',
      width: '70%',
      z: 100
    },
    grid: {
      containLabel: true
    },
    tooltip: {
        feature: {
            dataZoom: {
                yAxisIndex: 'none'
            },
        },
        show: true,
        trigger: 'axis'
    },
    xAxis: [{
            type: 'category',
            name: '时间',
            boundaryGap: true,
            data: ['0', '1', '2', '3', '4', '5', '6', '7','8','9','10', '11', '12', '13', '14', '15', '16', '17','18','19','20']
    }],
    yAxis: [{
        x: 'center',
        position: 'left',
        type: 'value',
        name: '时间',
        splitLine: {
          lineStyle: {
            type: 'dashed'
          }
        }
    }],
    dataZoom: [
        {
          type: 'inside',
        },
        {
          start: 0,
          end: 10
        }
    ],
    series: [{
      name: '设备一',
      type: 'line',
      smooth: true,
      sampling: 'lttb',      
    //   itemStyle: {
    //     color: 'rgb(255, 70, 131)'
    //   },
      data: data1
    },
    {
      name: '设备二',
      type: 'line',
      smooth: true,
      sampling: 'lttb',
      data: data2
    }]
  }; 
}