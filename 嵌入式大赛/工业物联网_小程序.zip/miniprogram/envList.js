const envList = [{"envId":"cloud1-5gnd6nnkee9785d1","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}